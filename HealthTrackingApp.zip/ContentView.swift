import SwiftUI
import QCBandSDK
import CoreData
import Charts

struct ContentView: View {
    @StateObject private var healthManager = HealthManager()
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \#keyPath(HealthRecord.timestamp), ascending: false)],
        animation: .default)
    private var records: FetchedResults<HealthRecord>
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Health Tracking App")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(.blue)
                
                VStack {
                    InfoCard(title: "Heart Rate", value: "\(healthManager.heartRate) BPM", color: .red)
                    InfoCard(title: "Steps", value: "\(healthManager.steps)", color: .blue)
                    InfoCard(title: "Sleep", value: "\(healthManager.sleepData) hrs", color: .green)
                }
                
                Toggle("Enable Background Sync", isOn: $healthManager.isBackgroundSyncEnabled)
                    .padding()
                
                Button(action: healthManager.scanAndConnect) {
                    Text("Scan & Connect")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding(.horizontal)
                
                ChartView(records: records)
            }
            .padding()
        }
    }
}